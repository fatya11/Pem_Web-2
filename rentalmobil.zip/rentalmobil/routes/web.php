<?php

use App\Http\Controllers\{MobilController,MerkController};
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MerkphpController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/welcome', function () {
    echo "Selamat Datang di Laravel";
});

Route::get('/greeting', function () {
    return view('greeting');
});

Route::get('/', function () {
    return view('index');
});

Route::get('/mobil', [MobilController::class, 'index']);
Route::get('/mobil/create', [MobilController::class, 'create']); //memanggil form
Route::post('/mobil/simpandata', [MobilController::class, 'store']); //mengirim request
route::get('/merk', [MerkController::class, 'index']);

Route::get('/merk/create', [MerkController::class, 'create']);
Route::post('/merk/simpan-data', [MerkController::class, 'store']);